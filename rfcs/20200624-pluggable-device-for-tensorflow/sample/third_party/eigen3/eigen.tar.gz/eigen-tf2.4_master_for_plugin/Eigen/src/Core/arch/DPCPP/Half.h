// This file is part of Eigen, a lightweight C++ template library
// for linear algebra.
//
// This Source Code Form is subject to the terms of the Mozilla
// Public License v. 2.0. If a copy of the MPL was not distributed
// with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
// The conversion routines are Copyright (c) Fabian Giesen, 2016.
// The original license follows:
//
// Copyright (c) Fabian Giesen, 2016
// All rights reserved.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


// Standard 16-bit float type, mostly useful for GPUs. Defines a new
// type Eigen::half (inheriting either from CUDA's or HIP's __half struct) with
// operator overloads such that it behaves basically as an arithmetic
// type. It will be quite slow on CPUs (so it is recommended to stay
// in fp32 for CPUs, except for simple parameter conversions, I/O
// to disk and the likes), but fast on GPUs.


#ifndef EIGEN_HALF_DPCPP_H
#define EIGEN_HALF_DPCPP_H

#ifdef DPCPP_DEVICE_ONLY

#if __cplusplus > 199711L
#define EIGEN_EXPLICIT_CAST(tgt_type) explicit operator tgt_type()
#else
#define EIGEN_EXPLICIT_CAST(tgt_type) operator tgt_type()
#endif


namespace Eigen {

struct half;

typedef union _u16_to_half {
  unsigned short u;
  cl::sycl::half h;
} u16_to_sycl_half;

namespace half_impl {

struct __half_raw {
  EIGEN_DEVICE_FUNC __half_raw() : x(0) {}
  explicit EIGEN_DEVICE_FUNC __half_raw(cl::sycl::half raw) : x(raw) {}
  explicit EIGEN_DEVICE_FUNC __half_raw(float ff) : x(ff) {}
  // ushort inintializer may be used elsewhere,
  // so keep it for potential compatibility
  explicit EIGEN_DEVICE_FUNC __half_raw(unsigned short raw) {
    u16_to_sycl_half u2h;
    u2h.u = raw;
    x = u2h.u;
  }
  cl::sycl::half x;
};

EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC __half_raw raw_uint16_to_half(unsigned short x);
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC __half_raw float_to_half_rtne(float ff);
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC float half_to_float(__half_raw h);

struct half_base : public __half_raw {
  EIGEN_DEVICE_FUNC half_base() {}
  EIGEN_DEVICE_FUNC half_base(const __half_raw& h) : __half_raw(h) {}
};

} // namespace half_impl

// Class definition.
struct half : public half_impl::half_base {

  EIGEN_DEVICE_FUNC half() {}

  EIGEN_DEVICE_FUNC half(const __half_raw& h) : half_impl::half_base(h) {}

  explicit EIGEN_DEVICE_FUNC half(float f) {
    x = static_cast<cl::sycl::half>(f);
  }
  // sycl c
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(bool) const {
    // +0.0 and -0.0 become false, everything else becomes true.
    return static_cast<bool>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(signed char) const {
    return static_cast<signed char>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(unsigned char) const {
    return static_cast<unsigned char>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(short) const {
    return static_cast<short>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(unsigned short) const {
    return static_cast<unsigned short>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(int) const {
    return static_cast<int>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(unsigned int) const {
    return static_cast<unsigned int>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(long) const {
    return static_cast<long>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(unsigned long) const {
    return static_cast<unsigned long>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(long long) const {
    return static_cast<long long>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(unsigned long long) const {
    return static_cast<unsigned long long>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(float) const {
    return static_cast<float>(x);
  }
  EIGEN_DEVICE_FUNC EIGEN_EXPLICIT_CAST(double) const {
    return static_cast<double>(x);
  }

  EIGEN_DEVICE_FUNC half& operator=(const half& other) {
    x = other.x;
    return *this;
  }

};

} // end namespace Eigen

namespace std {
template<>
struct numeric_limits<Eigen::half> {
  static const bool is_specialized = true;
  static const bool is_signed = true;
  static const bool is_integer = false;
  static const bool is_exact = false;
  static const bool has_infinity = true;
  static const bool has_quiet_NaN = true;
  static const bool has_signaling_NaN = true;
  static const float_denorm_style has_denorm = denorm_present;
  static const bool has_denorm_loss = false;
  static const std::float_round_style round_style = std::round_to_nearest;
  static const bool is_iec559 = false;
  static const bool is_bounded = false;
  static const bool is_modulo = false;
  static const int digits = 11;
  static const int digits10 = 3;      // according to http://half.sourceforge.net/structstd_1_1numeric__limits_3_01half__float_1_1half_01_4.html
  static const int max_digits10 = 5;  // according to http://half.sourceforge.net/structstd_1_1numeric__limits_3_01half__float_1_1half_01_4.html
  static const int radix = 2;
  static const int min_exponent = -13;
  static const int min_exponent10 = -4;
  static const int max_exponent = 16;
  static const int max_exponent10 = 4;
  static const bool traps = true;
  static const bool tinyness_before = false;

  static Eigen::half (min)() { return Eigen::half_impl::raw_uint16_to_half(0x400); }
  static Eigen::half lowest() { return Eigen::half_impl::raw_uint16_to_half(0xfbff); }
  static Eigen::half (max)() { return Eigen::half_impl::raw_uint16_to_half(0x7bff); }
  static Eigen::half epsilon() { return Eigen::half_impl::raw_uint16_to_half(0x0800); }
  static Eigen::half round_error() { return Eigen::half(0.5); }
  static Eigen::half infinity() { return Eigen::half_impl::raw_uint16_to_half(0x7c00); }
  static Eigen::half quiet_NaN() { return Eigen::half_impl::raw_uint16_to_half(0x7e00); }
  static Eigen::half signaling_NaN() { return Eigen::half_impl::raw_uint16_to_half(0x7e00); }
  static Eigen::half denorm_min() { return Eigen::half_impl::raw_uint16_to_half(0x1); }

};

// If std::numeric_limits<T> is specialized, should also specialize
// std::numeric_limits<const T>, std::numeric_limits<volatile T>, and
// std::numeric_limits<const volatile T>
// https://stackoverflow.com/a/16519653/
template<>
struct numeric_limits<const Eigen::half> : numeric_limits<Eigen::half> {};
template<>
struct numeric_limits<volatile Eigen::half> : numeric_limits<Eigen::half> {};
template<>
struct numeric_limits<const volatile Eigen::half> : numeric_limits<Eigen::half> {};
} // end namespace std

namespace Eigen {

namespace half_impl {

// sycl has these operator for half type
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half operator + (const half& a, const half& b) {
  return half(a.x + b.x);
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half operator * (const half& a, const half& b) {
  return half(a.x * b.x);
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half operator - (const half& a, const half& b) {
  return half(a.x - b.x);
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half operator / (const half& a, const half& b) {
  return half(a.x / b.x);
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half operator - (const half& a) {
  half tmp;
  tmp.x = - a.x;
  return tmp;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half& operator += (half& a, const half& b) {
  a.x += b.x;
  return a;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half& operator *= (half& a, const half& b) {
  a.x *= b.x;
  return a;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half& operator -= (half& a, const half& b) {
  a.x -= b.x;
  return a;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half& operator /= (half& a, const half& b) {
  a.x /= b.x;
  return a;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool operator == (const half& a, const half& b) {
  return a.x == b.x;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool operator != (const half& a, const half& b) {
  return a.x != b.x;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool operator < (const half& a, const half& b) {
  return a.x < b.x;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool operator <= (const half& a, const half& b) {
  return a.x <= b.x;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool operator > (const half& a, const half& b) {
  return a.x > b.x;
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool operator >= (const half& a, const half& b) {
  return a.x >= b.x;
}

// Division by an index. Do it in full float precision to avoid accuracy
// issues in converting the denominator to half.
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half operator / (const half& a, Index b) {
  return half(static_cast<float>(a) / static_cast<float>(b));
}

// Conversion routines, including fallbacks for the host or older CUDA.
// Note that newer Intel CPUs (Haswell or newer) have vectorized versions of
// these in hardware. If we need more performance on older/other CPUs, they are
// also possible to vectorize directly.

EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC __half_raw raw_uint16_to_half(unsigned short us) {
  __half_raw h;
  u16_to_sycl_half i;
  i.u = us;
  h.x = i.h;
  return h;
}

union float32_bits {
  unsigned int u;
  float f;
};

EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC __half_raw float_to_half_rtne(float ff) {
  float32_bits f;
  f.f = ff;

  const float32_bits f32infty = { 255 << 23 };
  const float32_bits f16max = { (127 + 16) << 23 };
  const float32_bits denorm_magic = { ((127 - 15) + (23 - 10) + 1) << 23 };
  unsigned int sign_mask = 0x80000000u;
  __half_raw o;
  u16_to_sycl_half u2h;
  u2h.u = static_cast<unsigned short>(0x0u);

  unsigned int sign = f.u & sign_mask;
  f.u ^= sign;

  // NOTE all the integer compares in this function can be safely
  // compiled into signed compares since all operands are below
  // 0x80000000. Important if you want fast straight SSE2 code
  // (since there's no unsigned PCMPGTD).

  if (f.u >= f16max.u) {  // result is Inf or NaN (all exponent bits set)
    u2h.u = (f.u > f32infty.u) ? 0x7e00 : 0x7c00; // NaN->qNaN and Inf->Inf
  } else {  // (De)normalized number or zero
    if (f.u < (113 << 23)) {  // resulting FP16 is subnormal or zero
      // use a magic value to align our 10 mantissa bits at the bottom of
      // the float. as long as FP addition is round-to-nearest-even this
      // just works.
      f.f += denorm_magic.f;

      // and one integer subtract of the bias later, we have our final float!
      u2h.u = static_cast<unsigned short>(f.u - denorm_magic.u);
    } else {
      unsigned int mant_odd = (f.u >> 13) & 1; // resulting mantissa is odd

      // update exponent, rounding bias part 1
      f.u += ((unsigned int)(15 - 127) << 23) + 0xfff;
      // rounding bias part 2
      f.u += mant_odd;
      // take the bits!
      u2h.u = static_cast<unsigned short>(f.u >> 13);
    }
  }

  u2h.u |= static_cast<unsigned short>(sign >> 16);
  o.x = u2h.h;
  return o;
}

// keep it for potential comptibility
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC float half_to_float(__half_raw h) {
  return static_cast<float>(h.x);
}

// --- standard functions ---

EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool (isinf)(const half& a) {
  return cl::sycl::isinf(a.x);
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool (isnan)(const half& a) {
  return cl::sycl::isnan(a.x);
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC bool (isfinite)(const half& a) {
  return cl::sycl::isfinite(a.x);
}

EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half acos(const half& a) {
  return Eigen::half(cl::sycl::acos(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half acosh(const half& a) {
  return Eigen::half(cl::sycl::acosh(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half acospi(const half& a) {
  return Eigen::half(cl::sycl::acospi(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half asin(const half& a) {
  return Eigen::half(cl::sycl::asin(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half asinh(const half& a) {
  return Eigen::half(cl::sycl::asinh(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half asinpi(const half& a) {
  return Eigen::half(cl::sycl::asinpi(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half atan(const half& a) {
  return Eigen::half(cl::sycl::atan(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half atan2(const half& a, const half& b) {
  return Eigen::half(cl::sycl::atan2(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half atanh(const half& a) {
  return Eigen::half(cl::sycl::atanh(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half atanpi(const half& a) {
  return Eigen::half(cl::sycl::atanpi(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half atan2pi(const half& a, const half& b) {
  return Eigen::half(cl::sycl::atan2pi(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half cbrt(const half& a) {
  return Eigen::half(cl::sycl::cbrt(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half ceil(const half& a) {
  return Eigen::half(cl::sycl::ceil(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half copysign(const half& a,const half& b) {
  return Eigen::half(cl::sycl::copysign(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half cos(const half& a) {
  return Eigen::half(cl::sycl::cos(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half cosh(const half& a) {
  return Eigen::half(cl::sycl::cosh(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half cospi(const half& a) {
  return Eigen::half(cl::sycl::cospi(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half erfc(const half& a) {
  return Eigen::half(cl::sycl::erfc(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half erf(const half& a) {
  return Eigen::half(cl::sycl::erf(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half exp(const half& a) {
  return Eigen::half(cl::sycl::exp(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half exp2(const half& a) {
  return Eigen::half(cl::sycl::exp2(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half exp10(const half& a) {
  return Eigen::half(cl::sycl::exp10(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half expm1(const half& a) {
  return Eigen::half(cl::sycl::expm1(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fabs(const half& a) {
  return Eigen::half(cl::sycl::fabs(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fdim(const half& a, const half& b) {
  return Eigen::half(cl::sycl::fdim(a.x, b.x));
}

EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half abs(const half& a) {
  return Eigen::half(cl::sycl::fabs(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half floor(const half& a) {
  return Eigen::half(cl::sycl::floor(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fma(const half& a, const half& b, const half& c) {
  return Eigen::half(cl::sycl::fma(a.x, b.x, c.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fmax(const half& a, const half& b) {
  return Eigen::half(cl::sycl::fmax(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fmin(const half& a, const half& b) {
  return Eigen::half(cl::sycl::fmin(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fmod(const half& a, const half& b) {
  return Eigen::half(cl::sycl::fmod(a.x, b.x));
}
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fract(const half& a, const half* b) {
//   return Eigen::half(cl::sycl::fract(a.x, &(b->x)));
// }
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half fract(const half& a, cl::sycl::cl_int* b) {
//   return Eigen::half(cl::sycl::fract(a.x, b));
// }
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half hypot(const half& a, const half& b) {
  return Eigen::half(cl::sycl::hypot(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half ilogb(const half& a) {
  return Eigen::half(cl::sycl::ilogb(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half ldexp(const half& a, cl::sycl::cl_int& b) {
  return Eigen::half(cl::sycl::ldexp(a.x, b));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half lgamma(const half& a) {
  return Eigen::half(cl::sycl::lgamma(a.x));
}
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half lgamma_r(const half& a, cl::sycl::cl_int* b) {
//   return Eigen::half(cl::sycl::lgamma_r(a.x, b));
// }
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half log(const half& a) {
  return Eigen::half(cl::sycl::log(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half log2(const half& a) {
  return Eigen::half(cl::sycl::log2(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half log10(const half& a) {
  return Eigen::half(cl::sycl::log10(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half log1p(const half& a) {
  return Eigen::half(cl::sycl::log1p(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half logb(const half& a) {
  return Eigen::half(cl::sycl::logb(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half mad(const half& a, const half& b, const half& c) {
  return Eigen::half(cl::sycl::mad(a.x, b.x, c.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half maxmag(const half& a, const half& b) {
  return Eigen::half(cl::sycl::maxmag(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half minmag(const half& a, const half& b) {
  return Eigen::half(cl::sycl::minmag(a.x, b.x));
}
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half modf(const half& a, const half* b) {
//   return Eigen::half(cl::sycl::modf(a.x, &(b->x)));
// }
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half nan(unsigned int u) {
  return Eigen::half(cl::sycl::nan(u));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half nextafter(const half& a, const half& b) {
  return Eigen::half(cl::sycl::nextafter(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half pow(const half& a, const half& b) {
  return Eigen::half(cl::sycl::pow(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half pow(const half& a, const cl::sycl::cl_int& b) {
  return Eigen::half(cl::sycl::pown(a.x, b));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half powr(const half& a, const half& b) {
  return Eigen::half(cl::sycl::powr(a.x, b.x));
}
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half remquo(const half& a, const half& b, const cl::sycl::cl_int* c) {
//   return Eigen::half(cl::sycl::remquo(a.x, b.x, c));
// }
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half rint(const half& a) {
  return Eigen::half(cl::sycl::rint(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half rootn(const half& a, const cl::sycl::cl_int& b) {
  return Eigen::half(cl::sycl::rootn(a.x, b));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half round(const half& a) {
  return Eigen::half(cl::sycl::round(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half rsqrt(const half& a) {
  return Eigen::half(cl::sycl::rsqrt(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half sin(const half& a) {
  return Eigen::half(cl::sycl::sin(a.x));
}
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half sincos(const half& a, const half* b) {
//   return Eigen::half(cl::sycl::sincos(a.x, b));
// }
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half sinh(const half& a) {
  return Eigen::half(cl::sycl::sinh(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half sinpi(const half& a) {
  return Eigen::half(cl::sycl::sinpi(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half sqrt(const half& a) {
  return Eigen::half(cl::sycl::sqrt(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half tan(const half& a) {
  return Eigen::half(cl::sycl::tan(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half tanh(const half& a) {
  return Eigen::half(cl::sycl::tanh(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half tanpi(const half& a) {
  return Eigen::half(cl::sycl::tanpi(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half tgamma(const half& a) {
  return Eigen::half(cl::sycl::tgamma(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half trunc(const half& a) {
  return Eigen::half(cl::sycl::trunc(a.x));
}
// only enable for type T which is_genfloatf<T>::value is true
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half divide(const half& a, const half& b) {
//   return Eigen::half(cl::sycl::half_precision::divide(a.x, b.x));
// }
// EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half recip(const half& a) {
//   return Eigen::half(cl::sycl::half_precision::recip(a.x));
// }
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half clamp(const half& a, const half& b, const half& c) {
  return Eigen::half(cl::sycl::clamp(a.x, b.x, c.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half degrees(const half& a) {
  return Eigen::half(cl::sycl::degrees(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half radians(const half& a) {
  return Eigen::half(cl::sycl::radians(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half step(const half& a, const half& b) {
  return Eigen::half(cl::sycl::step(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half smoothstep(const half& a, const half& b, const half& c) {
  return Eigen::half(cl::sycl::smoothstep(a.x, b.x, c.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half sign(const half& a) {
  return Eigen::half(cl::sycl::sign(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half (min)(const half& a, const half& b) {
  return Eigen::half(cl::sycl::min(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC half (max)(const half& a, const half& b) {
  return Eigen::half(cl::sycl::max(a.x, b.x));
}

#ifndef EIGEN_NO_IO
EIGEN_ALWAYS_INLINE std::ostream& operator << (std::ostream& os, const half& v) {
  os << static_cast<float>(v);
  return os;
}
#endif

} // end namespace half_impl

// import Eigen::half_impl::half into Eigen namespace
// using half_impl::half;

namespace internal {

template<>
struct random_default_impl<half, false, false>
{
  static inline half run(const half& x, const half& y)
  {
    return x + (y-x) * half(float(std::rand()) / float(RAND_MAX));
  }
  static inline half run()
  {
    return run(half(-1.f), half(1.f));
  }
};

template<> struct is_arithmetic<half> { enum { value = true }; };

} // end namespace internal

template<> struct NumTraits<Eigen::half>
    : GenericNumTraits<Eigen::half>
{
  enum {
    IsSigned = true,
    IsInteger = false,
    IsComplex = false,
    RequireInitialization = false
  };

  EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Eigen::half epsilon() {
    return half_impl::raw_uint16_to_half(0x0800);
  }
  EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Eigen::half dummy_precision() { return Eigen::half(1e-2f); }
  EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Eigen::half highest() {
    return half_impl::raw_uint16_to_half(0x7bff);
  }
  EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Eigen::half lowest() {
    return half_impl::raw_uint16_to_half(0xfbff);
  }
  EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Eigen::half infinity() {
    return half_impl::raw_uint16_to_half(0x7c00);
  }
  EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Eigen::half quiet_NaN() {
    return half_impl::raw_uint16_to_half(0x7c01);
  }
};

} // end namespace Eigen

// C-like standard mathematical functions and trancendentals.
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half fabsh(const Eigen::half& a) {
  return Eigen::half(cl::sycl::fabs(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half exph(const Eigen::half& a) {
  return Eigen::half(cl::sycl::exp(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half logh(const Eigen::half& a) {
  return Eigen::half(cl::sycl::log(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half sqrth(const Eigen::half& a) {
  return Eigen::half(cl::sycl::sqrt(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half powh(const Eigen::half& a, const Eigen::half& b) {
  return Eigen::half(cl::sycl::pow(a.x, b.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half floorh(const Eigen::half& a) {
  return Eigen::half(cl::sycl::floor(a.x));
}
EIGEN_STRONG_INLINE EIGEN_DEVICE_FUNC Eigen::half ceilh(const Eigen::half& a) {
  return Eigen::half(cl::sycl::ceil(a.x));
}

namespace std {

#if __cplusplus > 199711L
template <>
struct hash<Eigen::half> {
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE std::size_t operator()(const Eigen::half& a) const {
    return static_cast<std::size_t>(a.x);
  }
};
#endif

} // end namespace std

#if defined(EIGEN_GPU_COMPILE_PHASE)
namespace Eigen {
namespace numext {

template<>
EIGEN_DEVICE_FUNC EIGEN_ALWAYS_INLINE
bool (isnan)(const Eigen::half& h) {
  return cl::sycl::isnan(h.x);
}

template<>
EIGEN_DEVICE_FUNC EIGEN_ALWAYS_INLINE
bool (isinf)(const Eigen::half& h) {
  return cl::sycl::isinf(h.x);
}

template<>
EIGEN_DEVICE_FUNC EIGEN_ALWAYS_INLINE
bool (isfinite)(const Eigen::half& h) {
  return cl::sycl::isfinite(h.x);
}

} // namespace Eigen
}  // namespace numext
#endif

#endif //DPCPP_DEVICE_ONLY

#endif // EIGEN_HALF_DPCPP_H
